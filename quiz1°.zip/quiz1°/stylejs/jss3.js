// Liste des pays avec leur nom et le lien vers leur drapeau
const countries = [
    { name: "Emirats Arabes Unis", flag: "../img/dubai.png" },
    { name: "Jordanie", flag: "../img/jor.jpg" },
    { name: "Palestine", flag: "../img/pales.jpg" },
    { name: "Koweit", flag: "../img/kow.jpg" },
    { name: "Egypte", flag: "../img/egy.jpg" },
    { name: "Irak", flag: "../img/irak.png" },
    { name: "Syrie", flag: "../img/syrie.jpg" },
    { name: "Yemen", flag: "../img/yemen.jpg" },

];

// Index de la question actuelle
let currentQuestionIndex = 0;
// Score de l'utilisateur
let score = 0;

// Sélection des éléments HTML
const flagImage = document.getElementById('flag-image');
const choicesContainer = document.getElementById('choices');
const nextButton = document.getElementById('next-btn');
const scoreContainer = document.getElementById('score-container');

// Fonction pour démarrer le quiz
function startQuiz() {
    currentQuestionIndex = 0; // Réinitialise l'index de la question
    score = 0; // Réinitialise le score
    nextButton.style.display = 'none'; // Cache le bouton "Question suivante"
    scoreContainer.textContent = ''; // Efface le score affiché
    loadQuestion(); // Charge la première question
}

// Fonction pour charger la question actuelle
function loadQuestion() {
    resetChoices(); // Efface les choix précédents
    const currentCountry = countries[currentQuestionIndex]; // Récupère le pays actuel
    flagImage.src = currentCountry.flag; // Affiche l'image du drapeau

    // Génère les choix de réponses aléatoires
    const choices = shuffleChoices(currentCountry.name);
    choices.forEach(choice => {
        const button = document.createElement('button'); // Crée un bouton pour chaque choix
        button.textContent = choice; // Ajoute le texte du choix
        button.addEventListener('click', selectAnswer); // Ajoute un gestionnaire d'événement pour le clic
        choicesContainer.appendChild(button); // Ajoute le bouton au conteneur des choix
    });
}

// Fonction pour réinitialiser les choix
function resetChoices() {
    while (choicesContainer.firstChild) {
        choicesContainer.removeChild(choicesContainer.firstChild); // Supprime tous les boutons de choix
    }
}

// Fonction pour mélanger les choix de réponses
function shuffleChoices(correctAnswer) {
    const choices = [correctAnswer]; // Commence avec la bonne réponse
    while (choices.length < 4) {
        const randomCountry = countries[Math.floor(Math.random() * countries.length)].name;
        if (!choices.includes(randomCountry)) { // Ajoute une réponse aléatoire si elle n'est pas déjà présente
            choices.push(randomCountry);
        }
    }
    return choices.sort(() => Math.random() - 0.5); // Mélange les choix
}

// Fonction pour gérer la sélection d'une réponse
function selectAnswer(e) {
    const selectedAnswer = e.target.textContent; // Récupère le texte du bouton cliqué
    const currentCountry = countries[currentQuestionIndex];

    if (selectedAnswer === currentCountry.name) { // Vérifie si la réponse est correcte
        score++; // Incrémente le score
        e.target.style.backgroundColor = 'green'; // Change la couleur du bouton en vert
    } else {
        e.target.style.backgroundColor = 'red'; // Change la couleur du bouton en rouge
    }

    // Désactive tous les boutons de choix après la réponse
    Array.from(choicesContainer.children).forEach(button => button.disabled = true);
    nextButton.style.display = 'block'; // Affiche le bouton "Question suivante"
}

// Gestionnaire d'événement pour le bouton "Question suivante"
nextButton.addEventListener('click', () => {
    currentQuestionIndex++; // Passe à la question suivante
    if (currentQuestionIndex < countries.length) { // Vérifie s'il reste des questions
        loadQuestion(); // Charge la question suivante
        nextButton.style.display = 'none'; // Cache le bouton "Question suivante"
    } else {
        showScore(); // Affiche le score final
    }
});

// Fonction pour afficher le score final
function showScore() {
    scoreContainer.textContent = `Votre score est de ${score} sur ${countries.length}`; // Affiche le score
    nextButton.style.display = 'none'; // Cache le bouton "Question suivante"
    const linkToNextQuiz = document.createElement('a');
    linkToNextQuiz.textContent = 'Passer au quiz suivant';
    linkToNextQuiz.href = 'xtrem.html'; // Lien vers la nouvelle page de quiz
    linkToNextQuiz.style.display = 'block';
    linkToNextQuiz.style.marginTop = '20px';
    linkToNextQuiz.style.padding = '10px';
    linkToNextQuiz.style.backgroundColor = '#4CAF50';
    linkToNextQuiz.style.color = 'white';
    linkToNextQuiz.style.textDecoration = 'none';
    linkToNextQuiz.style.borderRadius = '5px';

    // Ajoute le lien au conteneur du score
    scoreContainer.appendChild(linkToNextQuiz);
}

// Démarre le quiz
startQuiz();